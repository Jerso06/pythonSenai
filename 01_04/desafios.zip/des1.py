import random

valor = random.randint(0,5)

if(int(input("Informe um valor entre 0 e 5: ")) == valor):
    print("Você acertou! ヾ(≧▽≦*)o")
else:
    print("Você errou (┬┬﹏┬┬)")