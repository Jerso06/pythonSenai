n1 = int(input("Informe um número: "))

if(n1%2 == 0):
    print("O número é PAR!")
else:
    print("O número é ÍMPAR!")