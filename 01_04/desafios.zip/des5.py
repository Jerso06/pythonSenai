ano = int(input("Informe um ano: "))

if(ano%4==0):
    print("É BISSEXTO")
else:
    print("Não é BISSEXTO")