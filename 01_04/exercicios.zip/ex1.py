n1 = float(input("Insira a primeira nota: "))
n2 = float(input("Insira a segunda nota: "))
media = (n1+n2)/2

if media >=6:
    print("Aprovado")
else:
    print("Reprovado")