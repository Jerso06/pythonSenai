n1 = float(input("Insira o primeiro número: "))
n2 = float(input("Insira o segundo número: "))

if n1>n2:
    print("Maior: ",n1, "\nMenor: ",n2)
else:
    print("Maior: ",n2, "\nMenor: ",n1)