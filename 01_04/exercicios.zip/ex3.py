n = int(input("Insira um número: "))

if n%2==0:
    print("Número par")
else:
    print("Número impar")