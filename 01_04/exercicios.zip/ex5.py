n1 = int(input("informe o primeiro numero: "))
n2 = int(input("informe o segundo numero: "))

if n1==n2:
    print("Os números são iguais")
else:
    print("Os números são diferentes")
