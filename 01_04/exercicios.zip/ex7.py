compra = float(input("Informe o valor da compra: "))
prestacoes = int(input("Informe o valor das prestações: "))

valorPrest = compra/prestacoes

print("Valor das prestações: R$",valorPrest)