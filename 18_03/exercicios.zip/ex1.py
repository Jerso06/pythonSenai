n1 = int(input("Insira um valor: "))
n2 = int(input("Insira um valor: "))
soma = n1+n2;

print(soma)