preco = float(input("Insira o preço: "))
print("O valor com 5% de desconto equivale a: ",preco*0.95)