sal = float(input("Informe seu salário: "))

print("Seu salário com 15% de aumento equivale a: ",sal*1.15)