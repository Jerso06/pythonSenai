n = int(input("Insira um número"))

print("O sucessor do número selecionado é", n+1, "e seu antecessor é" , n-1)