n = int(input("insira um número: "))
print("Dobro = " , n*2 , "\nTriplo = " , n*3 , "\nQuadrado = " , n*n)