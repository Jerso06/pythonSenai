m = float(input("Insira o valor em metros: "))
print("Valor em centímetros: ", m*100 , "\nValor em milímetros: ", m*1000)