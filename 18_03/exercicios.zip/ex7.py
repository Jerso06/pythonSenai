n = int(input("Insira um número: "))
cont = 0

while cont <= 10:
    print(n,"x",cont,"=",n*cont)
    cont+=1