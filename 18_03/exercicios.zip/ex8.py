valor = float(input("Insira quanto você tem: "))
print("Você pode comprar ",valor/5," dólares")