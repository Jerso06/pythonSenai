largura = float(input("Insira a largura: "))
altura = float(input("Insira a altura: "))
area = largura*altura
litros = area/2

print("Área: ",area,"\nLitros necessários: ",litros)
